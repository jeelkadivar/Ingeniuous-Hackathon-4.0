const PORT = process.env.PORT || 3000;
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
// const methodOverride = require("method-override");
// const flash = require("connect-flash");
// const passport = require("passport");
// const LocalStrategy = require("passport-local");
// const LocalMongooseStrategy = require("passport-local-mongoose");
const mongoose = require("mongoose");
// const Idea = require("./models/ideas");
// const Product = require("./models/products");
// const Cmntproduct = require("./models/cmntProducts");
// const Cmntidea = require("./models/cmntIdeas");
// const User = require("./models/users");

//jk
// const date = require(__dirname + "/date.js");
const cors = require('cors');
const { connection } = require('mongoose');
let workItems = [];
const connections = require('./database.js');
const e = require('express');
const User = connections.models.userData;
const session = require('express-session');
const MongoStore = require('connect-mongo');
//jk

mongoose.connect("mongodb+srv://Malaypatel44:getup@meds.l4udp5g.mongodb.net/test",{
    useNewUrlParser : true,
    useUnifiedTopology : true
})
.then(()=> console.log("Connected to DB!!"))
.catch(()=> console.log("error.meassage"));

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended : true}));
// app.use(methodOverride("_method"));
app.locals.moment = require("moment");
// app.use(flash());

app.use(require("express-session")({
    secret : "Our little secret.",
    resave : false,
    saveUninitialized : false
}));


//==========
//Main Route
//==========
app.get("/",(req,res) => {
    res.redirect("/home");
})
//home route
app.get("/home",(req,res) => {
    res.sendFile(__dirname+"/public/index.html");
})

app.get("/resources",(req,res) => {
    res.render("resources.ejs");
})



app.post("/register", function (req, res) {
  var userN = req.body.username;
  var passW = req.body.password;
  console.log(userN);
  console.log(passW);
  User.findOne({ name: userN })
    .then((user) => {
      if (user) {
        res.send('<script>alert("username already exists");window.location.replace("http://localhost:3000/register");</script>')
      }
      else {
        const newuser = new User({
          name: userN,
          password: passW
        })
        newuser.save().then((user) => {
          console.log(user);
          console.log("Signed up successfully!");
          res.redirect("/home");
        })
      }
    })
});

 
app.post("/login", function (req, res) {
  var userN = req.body.username;
  var passW = req.body.password;
  console.log(userN);
  console.log(passW);
  User.findOne({ name: userN })
    .then((user) => {
      if (user) {
        console.log(user);
        if (user.password == passW) {
          req.session.userid = user._id;
          console.log("Loggedin successfully!");
          res.redirect("/home");
        }
        else {
          res.redirect("/login");
        }
      }
      else {
        res.redirect("/login");
      }
    })
});


 //Show Regiter
app.get("/register",(req,res) =>{
    res.render("register.ejs");
})
//Show Login
app.get("/login", (req,res) => {
    res.render("login.ejs");
})
//Logout
app.get("/logout",(req,res) => {
    req.logout();
    res.redirect("/home");
})


//Listen Route
app.listen(PORT,() => {
    console.log("Server has started successfully!!");
})  