const { json } = require('express');
const mongoose = require('mongoose');

// require('dotenv').config();

const conn = "mongodb+srv://Malaypatel44:getup@meds.l4udp5g.mongodb.net/test";

const connection = mongoose.createConnection(conn, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const UserSchema = new mongoose.Schema({
    name: String,
    password: String,
    todolist: [{
        Date: String,
        list: Array,
    }],
});

const User = connection.model('userData', UserSchema, 'userData');

module.exports = connection;